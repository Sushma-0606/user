package com.martmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MartManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MartManagementApplication.class, args);
	}

}
