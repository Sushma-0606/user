package com.martmanagement.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.martmanagement.entity.DeliverySlot;

public interface DeliverySlotRepository extends JpaRepository<DeliverySlot, Long> {

	List<DeliverySlot> findByDate(LocalDate date);
}
