package com.martmanagement.service;

import java.time.LocalDate;
import java.util.List;

import com.martmanagement.request.DeliverySlotModel;

public interface DeliverySlotService {

	DeliverySlotModel addDeliverySlot(DeliverySlotModel deliverySlotRequest);
    List<DeliverySlotModel> getDeliverySlotsByDate(LocalDate localDate);
    
}
