package com.martmanagement.service;

import com.martmanagement.request.ProductModel;

public interface ProductService {
	
	ProductModel addOrUpdate(ProductModel productRequest);
	
}
